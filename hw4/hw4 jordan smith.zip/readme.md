#readme
---
This week i felt like i had to go back over the functions and if else statements. It was harder for me to see the bigger picture in my coding but i felt i understand the logic of the coding better. I struggled with getting the functionality of the story to work but my logic was fine.
---
i feel i need to keep going over the basics to understand the possibilities of what i can do with coding. The example video helped with some issues i was having.
