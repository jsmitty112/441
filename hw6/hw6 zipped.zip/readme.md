# Read me
---
This week i felt better going over arrays and using them with functions. I had bit difficulty with going back and forth between files but i feel it is where it should be. I used the website video for help. It was a challenge to find what exactly went wrong displaying the game. My main logic of the code seems right but something is off with it. 
